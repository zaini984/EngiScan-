
import { ResumeData, SavedReport } from "../types";

const STORAGE_KEYS = {
  CANDIDATES: 'engiscan_candidates',
  REPORTS: 'engiscan_reports'
};

export const storageService = {
  getCandidates: (): ResumeData[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CANDIDATES);
    return data ? JSON.parse(data) : [];
  },

  saveCandidates: (candidates: ResumeData[]) => {
    localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify(candidates));
  },

  addCandidate: (candidate: ResumeData) => {
    const current = storageService.getCandidates();
    storageService.saveCandidates([...current, candidate]);
  },

  clearCandidates: () => {
    localStorage.removeItem(STORAGE_KEYS.CANDIDATES);
  },

  getReports: (): SavedReport[] => {
    const data = localStorage.getItem(STORAGE_KEYS.REPORTS);
    return data ? JSON.parse(data) : [];
  },

  saveReport: (report: SavedReport) => {
    const current = storageService.getReports();
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify([...current, report]));
  },

  deleteReport: (id: string) => {
    const current = storageService.getReports();
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(current.filter(r => r.id !== id)));
  }
};
