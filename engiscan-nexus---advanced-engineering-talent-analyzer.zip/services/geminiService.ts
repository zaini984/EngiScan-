
import { GoogleGenAI, Type } from "@google/genai";
import { ResumeData, AnalysisReport, ComparisonResult, ATSResult, ResumeBuilderInput } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const parseResume = async (base64Data: string, mimeType: string, fileName: string): Promise<ResumeData> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        },
        {
          text: `Extract structured information from this resume file. 
          Ensure accuracy and do not hallucinate information. 
          Analyze the file content carefully to identify dates, roles, and skills.
          If a field is missing, leave it empty.
          Filename: ${fileName}`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          fullName: { type: Type.STRING },
          contact: {
            type: Type.OBJECT,
            properties: {
              email: { type: Type.STRING },
              phone: { type: Type.STRING },
              location: { type: Type.STRING },
              linkedin: { type: Type.STRING },
              github: { type: Type.STRING }
            },
            required: ["email", "phone", "location"]
          },
          totalYearsExperience: { type: Type.NUMBER },
          education: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                degree: { type: Type.STRING },
                institution: { type: Type.STRING },
                year: { type: Type.STRING },
                gpa: { type: Type.STRING }
              }
            }
          },
          skills: { type: Type.ARRAY, items: { type: Type.STRING } },
          experience: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                company: { type: Type.STRING },
                period: { type: Type.STRING },
                description: { type: Type.STRING }
              }
            }
          },
          projects: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                technologies: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          certifications: { type: Type.ARRAY, items: { type: Type.STRING } },
          summary: { type: Type.STRING }
        },
        required: ["fullName", "skills", "experience"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response text from Gemini");
  
  const parsed = JSON.parse(text);
  return {
    ...parsed,
    id: crypto.randomUUID(),
    fileName,
    uploadedAt: new Date().toISOString()
  };
};

export const calculateATSScore = async (base64Data: string, mimeType: string): Promise<ATSResult> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        },
        {
          text: `Act as a senior Applicant Tracking System (ATS) expert. Analyze the attached resume for ATS compatibility and overall impact.
          Calculate an ATS score (0-100) based on readability, keyword density, layout, and content quality.
          Provide specific actionable suggestions for improvement.`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          overallFeedback: { type: Type.STRING },
          formattingScore: { type: Type.NUMBER },
          missingKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                category: { type: Type.STRING },
                score: { type: Type.NUMBER },
                feedback: { type: Type.STRING },
                suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          }
        },
        required: ["score", "overallFeedback", "sections"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No ATS result from Gemini");
  return JSON.parse(text);
};

export const compareCandidates = async (candidates: ResumeData[]): Promise<ComparisonResult> => {
  // Switched to flash-preview for better stability and quota management
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are an expert Talent Acquisition lead. Compare these engineering candidates for a high-growth tech environment.
    Evaluate based on technical skills, experience progression, and project impact.
    Candidates: ${JSON.stringify(candidates.map(c => ({
      id: c.id,
      name: c.fullName,
      skills: c.skills,
      experience: c.experience,
      totalYears: c.totalYearsExperience
    })))}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          bestFitId: { type: Type.STRING },
          ranking: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                candidateId: { type: Type.STRING },
                score: { type: Type.NUMBER },
                reason: { type: Type.STRING }
              }
            }
          },
          consolidatedReasoning: { type: Type.STRING }
        },
        required: ["bestFitId", "ranking", "consolidatedReasoning"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No comparison result from Gemini");
  return JSON.parse(text);
};

export const analyzeCandidate = async (candidate: ResumeData): Promise<AnalysisReport> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Provide a SWOT analysis for the following candidate profile.
    
    Candidate: ${JSON.stringify(candidate)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          candidateId: { type: Type.STRING },
          candidateName: { type: Type.STRING },
          score: { type: Type.NUMBER },
          strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
          weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
          roleFitRating: { type: Type.STRING },
          detailedAnalysis: { type: Type.STRING }
        },
        required: ["score", "strengths", "weaknesses", "roleFitRating", "detailedAnalysis"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No analysis result from Gemini");
  const result = JSON.parse(text);
  return { ...result, candidateId: candidate.id, candidateName: candidate.fullName };
};

export const generateProfessionalResume = async (input: ResumeBuilderInput): Promise<ResumeBuilderInput> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Act as a world-class executive resume writer. Polish the following details into a high-impact, professional, text-based resume.
    
    1. SUMMARY: Write a sophisticated 3-4 sentence professional summary that captures the essence of their career.
    2. EXPERIENCE: Rewrite all points as achievement-oriented bullet points using the STAR method (Situation, Task, Action, Result). Use strong active verbs.
    3. PROJECTS: Refine descriptions to highlight technical mastery and practical outcomes.
    4. SKILLS: Categorize and polish skills for clarity.

    Input Data: ${JSON.stringify(input)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          fullName: { type: Type.STRING },
          email: { type: Type.STRING },
          phone: { type: Type.STRING },
          location: { type: Type.STRING },
          linkedin: { type: Type.STRING },
          portfolio: { type: Type.STRING },
          summary: { type: Type.STRING },
          education: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                degree: { type: Type.STRING },
                school: { type: Type.STRING },
                date: { type: Type.STRING },
                gpa: { type: Type.STRING }
              }
            }
          },
          experience: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                company: { type: Type.STRING },
                date: { type: Type.STRING },
                points: { type: Type.STRING }
              },
              required: ["title", "company", "date", "points"]
            }
          },
          projects: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                tech: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["name", "tech", "description"]
            }
          },
          skills: { type: Type.STRING },
          certifications: { type: Type.STRING }
        },
        required: ["fullName", "summary", "experience", "skills", "education"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No generation result from Gemini");
  return JSON.parse(text);
};
