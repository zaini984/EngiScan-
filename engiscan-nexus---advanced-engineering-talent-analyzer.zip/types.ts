
export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export interface ContactDetails {
  email: string;
  phone: string;
  location: string;
  linkedin?: string;
  github?: string;
}

export interface Education {
  degree: string;
  institution: string;
  year: string;
  gpa?: string;
}

export interface Experience {
  role: string;
  company: string;
  period: string;
  description: string;
}

export interface Project {
  name: string;
  description: string;
  technologies: string[];
}

export interface ResumeData {
  id: string;
  fullName: string;
  contact: ContactDetails;
  totalYearsExperience: number;
  education: Education[];
  skills: string[];
  experience: Experience[];
  projects: Project[];
  certifications: string[];
  summary: string;
  fileName: string;
  uploadedAt: string;
}

export interface AnalysisReport {
  candidateId: string;
  candidateName: string;
  score: number; // 0-100
  strengths: string[];
  weaknesses: string[];
  roleFitRating: string;
  detailedAnalysis: string;
}

export interface ComparisonResult {
  bestFitId: string;
  ranking: { candidateId: string; score: number; reason: string }[];
  consolidatedReasoning: string;
}

export interface ATSResult {
  score: number;
  sections: {
    category: string;
    score: number;
    feedback: string;
    suggestions: string[];
  }[];
  overallFeedback: string;
  missingKeywords: string[];
  formattingScore: number;
}

export interface SavedReport {
  id: string;
  name: string;
  type: 'SINGLE' | 'CONSOLIDATED' | 'ATS' | 'GENERATED_RESUME';
  createdAt: string;
  data: any;
}

export interface ResumeBuilderInput {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  linkedin?: string;
  portfolio?: string;
  summary?: string;
  education: { degree: string; school: string; date: string; gpa?: string }[];
  experience: { title: string; company: string; date: string; points: string }[];
  projects: { name: string; tech: string; description: string }[];
  skills: string;
  certifications: string;
}
