
import React from 'react';
import { Users, FileText, Award, BarChart3, TrendingUp, Clock } from 'lucide-react';
import { ResumeData, SavedReport } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  candidates: ResumeData[];
  reports: SavedReport[];
}

const Dashboard: React.FC<DashboardProps> = ({ candidates, reports }) => {
  const avgExperience = candidates.length 
    ? (candidates.reduce((acc, curr) => acc + (curr.totalYearsExperience || 0), 0) / candidates.length).toFixed(1)
    : 0;

  const topSkills = Array.from(
    candidates.flatMap(c => c.skills || [])
      .reduce((acc, skill) => {
        acc.set(skill, (acc.get(skill) || 0) + 1);
        return acc;
      }, new Map<string, number>())
      .entries()
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => ({ name, count }));

  const COLORS = ['#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899'];

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Candidates" 
          value={candidates.length} 
          icon={<Users className="w-6 h-6 text-indigo-600" />} 
          trend="+12% from last week"
        />
        <StatCard 
          title="Reports Generated" 
          value={reports.length} 
          icon={<FileText className="w-6 h-6 text-emerald-600" />} 
          trend="Real-time storage"
        />
        <StatCard 
          title="Avg. Experience" 
          value={`${avgExperience} Yrs`} 
          icon={<Award className="w-6 h-6 text-amber-600" />} 
          trend="Seniority focus"
        />
        <StatCard 
          title="Processing Time" 
          value="~4s" 
          icon={<Clock className="w-6 h-6 text-blue-600" />} 
          trend="Gemini Flash Engine"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Top Skills Chart */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-500" />
              Talent Skill Distribution
            </h3>
          </div>
          <div className="h-[300px]">
            {topSkills.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topSkills} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={100} 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#64748b', fontSize: 12 }} 
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {topSkills.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyState message="No skill data available. Upload resumes to see analytics." />
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              Recent Pipeline
            </h3>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto">
            {candidates.slice(-5).reverse().map((c) => (
              <div key={c.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                  {c.fullName.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800 truncate">{c.fullName}</p>
                  <p className="text-xs text-slate-500 truncate">{c.experience?.[0]?.role || 'General Profile'}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400">{new Date(c.uploadedAt).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
            {candidates.length === 0 && <EmptyState message="No candidates in pipeline." />}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, trend }: { title: string; value: string | number; icon: React.ReactNode; trend: string }) => (
  <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className="p-3 bg-slate-50 rounded-lg">{icon}</div>
      <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">{trend}</span>
    </div>
    <h3 className="text-sm font-medium text-slate-500">{title}</h3>
    <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
  </div>
);

const EmptyState = ({ message }: { message: string }) => (
  <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-2">
    <div className="p-4 bg-slate-50 rounded-full">
      <FileText className="w-8 h-8 text-slate-300" />
    </div>
    <p className="text-slate-400 text-sm max-w-[200px]">{message}</p>
  </div>
);

export default Dashboard;
