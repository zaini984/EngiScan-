
import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Loader2, PlayCircle, Star, Sparkles, Files, Target, Zap, ListChecks } from 'lucide-react';
import { parseResume, analyzeCandidate, compareCandidates, calculateATSScore } from '../services/geminiService';
import { storageService } from '../services/storageService';
import { ResumeData, AnalysisReport, ComparisonResult, UserRole, ATSResult } from '../types';

interface UploadSectionProps {
  candidates: ResumeData[];
  onComplete: () => void;
  role: UserRole;
}

const UploadSection: React.FC<UploadSectionProps> = ({ candidates, onComplete, role }) => {
  const [activeSubTab, setActiveSubTab] = useState<'compare' | 'ats'>('compare');
  const [files, setFiles] = useState<File[]>([]);
  const [status, setStatus] = useState<'idle' | 'parsing' | 'comparing' | 'scoring' | 'done'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [atsResult, setAtsResult] = useState<ATSResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setError(null);
      const selectedFiles = Array.from(e.target.files);
      if (activeSubTab === 'ats' && selectedFiles.length > 1) {
        setError("ATS Optimizer supports one resume at a time.");
        setFiles([selectedFiles[0]]);
      } else {
        setFiles(selectedFiles);
      }
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = reader.result as string;
        const base64Data = base64String.split(',')[1];
        resolve(base64Data);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const processCompare = async () => {
    if (files.length === 0) return;
    if (files.length < 2) {
      setError("Please select at least 2 resumes to compare.");
      return;
    }
    
    setError(null);
    setStatus('parsing');
    setProgress({ current: 0, total: files.length });
    const parsedCandidates: ResumeData[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const base64Data = await fileToBase64(file);
        let mimeType = file.type || 'application/pdf';
        const data = await parseResume(base64Data, mimeType, file.name);
        storageService.addCandidate(data);
        parsedCandidates.push(data);
        setProgress(prev => ({ ...prev, current: i + 1 }));
      } catch (err: any) {
        console.error(`Failed to parse ${file.name}`, err);
        setError(`Failed to extract data from ${file.name}.`);
      }
    }

    if (parsedCandidates.length > 1) {
      setStatus('comparing');
      try {
        const comp = await compareCandidates(parsedCandidates);
        setComparison(comp);
        storageService.saveReport({
          id: crypto.randomUUID(),
          name: `Comparison - ${new Date().toLocaleDateString()} (${parsedCandidates.length} Candidates)`,
          type: 'CONSOLIDATED',
          createdAt: new Date().toISOString(),
          data: { comparison: comp, candidates: parsedCandidates }
        });
      } catch (err: any) {
        console.error("Comparison error:", err);
        setError(`Comparison step failed: ${err.message || 'Unknown error'}. Try smaller files or fewer candidates.`);
      }
    }
    setStatus('done');
    onComplete();
  };

  const processATS = async () => {
    if (files.length === 0) return;
    setError(null);
    setStatus('scoring');
    
    try {
      const file = files[0];
      const base64Data = await fileToBase64(file);
      let mimeType = file.type || 'application/pdf';
      const result = await calculateATSScore(base64Data, mimeType);
      setAtsResult(result);
      
      storageService.saveReport({
        id: crypto.randomUUID(),
        name: `ATS Score - ${file.name}`,
        type: 'ATS',
        createdAt: new Date().toISOString(),
        data: result
      });
    } catch (err: any) {
      console.error("ATS scoring error:", err);
      setError(`ATS Scoring failed: ${err.message || 'Unknown error'}.`);
    }
    setStatus('done');
    onComplete();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Sub-Tabs Selector */}
      <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm w-fit mx-auto mb-4">
        <button 
          onClick={() => { setActiveSubTab('compare'); setFiles([]); setStatus('idle'); setComparison(null); setAtsResult(null); setError(null); }}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeSubTab === 'compare' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <Target className="w-4 h-4" />
          Compare Candidates
        </button>
        <button 
          onClick={() => { setActiveSubTab('ats'); setFiles([]); setStatus('idle'); setComparison(null); setAtsResult(null); setError(null); }}
          className={`px-6 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeSubTab === 'ats' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <Zap className="w-4 h-4" />
          ATS Optimizer
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-start gap-3 text-red-700 animate-in fade-in">
          <AlertCircle className="w-5 h-5 mt-0.5" />
          <div className="text-sm font-medium">{error}</div>
        </div>
      )}

      {/* Upload Zone */}
      <div className={`bg-white p-10 rounded-2xl border-2 border-dashed transition-all ${files.length > 0 ? 'border-indigo-300 bg-indigo-50/10' : 'border-slate-200 hover:border-indigo-200'}`}>
        <input 
          type="file" 
          multiple={activeSubTab === 'compare'} 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".pdf,.docx,.doc,.txt"
        />
        
        {status === 'idle' ? (
          <div className="text-center">
            <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4 ${activeSubTab === 'ats' ? 'bg-amber-100' : 'bg-indigo-100'}`}>
              {activeSubTab === 'ats' ? <Zap className="w-8 h-8 text-amber-600" /> : <Upload className="w-8 h-8 text-indigo-600" />}
            </div>
            <h3 className="text-lg font-semibold text-slate-800">
              {activeSubTab === 'ats' ? 'Check ATS Compatibility' : 'Upload Multiple Resumes'}
            </h3>
            <p className="text-slate-500 mt-2 mb-6 max-w-sm mx-auto">
              {activeSubTab === 'ats' 
                ? 'Upload your resume to get an ATS score and improvement suggestions based on industry standards.'
                : 'Drop 2 or more resumes here to determine the best engineering fit using AI logic.'
              }
            </p>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-indigo-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-indigo-700 shadow-md shadow-indigo-100 flex items-center gap-2 mx-auto"
            >
              <Files className="w-5 h-5" />
              {activeSubTab === 'ats' ? 'Select Resume' : 'Select Files'}
            </button>
          </div>
        ) : status === 'done' ? (
           <div className="text-center py-4">
             <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-3">
               <CheckCircle className="w-6 h-6 text-emerald-600" />
             </div>
             <h3 className="text-lg font-semibold text-slate-800">Analysis Ready</h3>
             <button 
              onClick={() => { setFiles([]); setStatus('idle'); setComparison(null); setAtsResult(null); setError(null); }}
              className="mt-4 text-indigo-600 font-bold text-sm hover:underline"
             >
               Start New Analysis
             </button>
           </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-indigo-600 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                {status === 'parsing' ? `Parsing Resumes (${progress.current}/${progress.total})` : 
                 status === 'comparing' ? 'Generating Comparison...' : 'Calculating ATS Score...'}
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div 
                className="bg-indigo-600 h-2 rounded-full transition-all duration-500" 
                style={{ width: status === 'parsing' ? `${(progress.current / progress.total) * 100}%` : '100%' }}
              ></div>
            </div>
          </div>
        )}

        {files.length > 0 && status === 'idle' && (
          <div className="mt-8 border-t border-slate-100 pt-6">
            <h4 className="text-sm font-medium text-slate-700 mb-4 flex items-center gap-2">
              Selected ({files.length})
              <button onClick={() => setFiles([])} className="text-red-500 hover:underline text-xs ml-auto font-bold uppercase">Clear</button>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {files.map((f, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-white border border-slate-100 rounded-lg shadow-sm">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  <span className="text-sm text-slate-600 truncate flex-1">{f.name}</span>
                </div>
              ))}
            </div>
            <button 
              onClick={activeSubTab === 'compare' ? processCompare : processATS}
              className="mt-6 w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-indigo-600 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-6 h-6" />
              {activeSubTab === 'ats' ? 'GENERATE ATS SCORE' : 'START AI PIPELINE'}
            </button>
          </div>
        )}
      </div>

      {/* Comparison Results Card */}
      {comparison && activeSubTab === 'compare' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-500">
          <div className="bg-gradient-to-r from-indigo-900 to-slate-900 p-10 text-white">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 text-indigo-300 mb-3">
                  <Star className="w-6 h-6 fill-current text-amber-400" />
                  <span className="text-sm font-black tracking-[0.2em] uppercase">Best Fit Candidate Found</span>
                </div>
                <h2 className="text-4xl font-black tracking-tight mb-4 leading-tight">
                  {candidates.find(c => c.id === comparison.bestFitId)?.fullName || 'Top Candidate'}
                </h2>
              </div>
              <div className="bg-white/10 p-6 rounded-2xl border border-white/10 backdrop-blur-md text-center min-w-[140px]">
                <div className="text-xs text-indigo-300 font-bold uppercase mb-1">Match Score</div>
                <div className="text-6xl font-black text-white">
                  {comparison.ranking?.find(r => r.candidateId === comparison.bestFitId)?.score || 0}%
                </div>
              </div>
            </div>
            <p className="text-xl text-indigo-50 leading-relaxed font-medium mt-6 italic">
              " {comparison.consolidatedReasoning || 'N/A'} "
            </p>
          </div>

          <div className="p-8 bg-slate-50/50">
            <h3 className="font-black text-slate-800 mb-8 flex items-center gap-3 text-lg uppercase tracking-tight">
              Comparative Ranking
            </h3>
            <div className="space-y-4">
              {(comparison.ranking || []).sort((a,b) => b.score - a.score).map((rank, idx) => {
                const c = candidates.find(can => can.id === rank.candidateId);
                const isBest = rank.candidateId === comparison.bestFitId;
                return (
                  <div key={rank.candidateId} className={`flex flex-col md:flex-row gap-6 p-6 rounded-2xl border transition-all ${isBest ? 'bg-white border-indigo-200 shadow-lg' : 'bg-white/60 border-slate-200'}`}>
                    <div className="flex items-center gap-6 md:w-1/3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${isBest ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
                        {idx + 1}
                      </div>
                      <h4 className="font-bold text-slate-900 text-lg">{c?.fullName}</h4>
                    </div>
                    <div className="flex-1 text-sm text-slate-600 italic">
                      {rank.reason}
                    </div>
                    <div className="text-2xl font-black text-slate-800 md:w-16 text-right">{rank.score}%</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadSection;
