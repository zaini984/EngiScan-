
import React, { useState, useRef } from 'react';
import { User, Mail, MapPin, Phone, Briefcase, GraduationCap, Code, Award, Plus, Trash2, Sparkles, FileDown, ArrowLeft, Loader2, Globe, Linkedin } from 'lucide-react';
import { generateProfessionalResume } from '../services/geminiService';
import { ResumeBuilderInput } from '../types';
import { storageService } from '../services/storageService';

/**
 * Helper component for form sections
 */
const Section: React.FC<{
  icon: React.ReactNode;
  title: string;
  onAdd?: () => void;
  children?: React.ReactNode;
}> = ({ icon, title, children, onAdd }) => (
  <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
    <div className="flex items-center justify-between mb-8">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-indigo-50 rounded-xl">{icon}</div>
        <h3 className="text-xl font-bold text-slate-800 tracking-tight uppercase">{title}</h3>
      </div>
      {onAdd && (
        <button onClick={onAdd} className="p-2 text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors">
          <Plus className="w-5 h-5" />
        </button>
      )}
    </div>
    {children}
  </div>
);

/**
 * Helper component for form inputs
 */
const Input = ({ label, value, onChange, placeholder, name, type = "text" }: { 
  label: string; 
  value: string; 
  onChange: (v: string) => void; 
  placeholder?: string; 
  name?: string;
  type?: string;
}) => (
  <div className="space-y-1">
    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">{label}</label>
    <input 
      type={type} 
      name={name}
      value={value} 
      onChange={(e) => onChange(e.target.value)} 
      placeholder={placeholder}
      className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none border-transparent transition-all"
    />
  </div>
);

const ResumeBuilder: React.FC = () => {
  const [step, setStep] = useState<'form' | 'loading' | 'preview'>('form');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [formData, setFormData] = useState<ResumeBuilderInput>({
    fullName: '',
    email: '',
    phone: '',
    location: '',
    linkedin: '',
    portfolio: '',
    education: [{ degree: '', school: '', date: '' }],
    experience: [{ title: '', company: '', date: '', points: '' }],
    projects: [{ name: '', tech: '', description: '' }],
    skills: '',
    certifications: ''
  });

  const [polishedData, setPolishedData] = useState<ResumeBuilderInput | null>(null);

  const handleArrayChange = (index: number, field: string, value: string, section: 'education' | 'experience' | 'projects') => {
    const newSection = [...formData[section]] as any[];
    newSection[index][field] = value;
    setFormData({ ...formData, [section]: newSection });
  };

  const addRow = (section: 'education' | 'experience' | 'projects') => {
    const templates = {
      education: { degree: '', school: '', date: '' },
      experience: { title: '', company: '', date: '', points: '' },
      projects: { name: '', tech: '', description: '' }
    };
    setFormData({ ...formData, [section]: [...formData[section], templates[section]] });
  };

  const removeRow = (index: number, section: 'education' | 'experience' | 'projects') => {
    const newSection = formData[section].filter((_, i) => i !== index);
    setFormData({ ...formData, [section]: newSection });
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenerate = async () => {
    if (!formData.fullName) {
      alert("Please enter at least your full name.");
      return;
    }
    setStep('loading');
    setErrorMsg(null);
    try {
      const polished = await generateProfessionalResume(formData);
      if (!polished) throw new Error("AI returned empty data");
      
      setPolishedData(polished);
      setStep('preview');
      
      storageService.saveReport({
        id: crypto.randomUUID(),
        name: `Resume - ${polished.fullName}`,
        type: 'GENERATED_RESUME',
        createdAt: new Date().toISOString(),
        data: polished
      });
    } catch (err) {
      console.error("Resume Generation Error:", err);
      setErrorMsg("Failed to generate polished resume. Please ensure your API key is correct and try again.");
      setStep('form');
    }
  };

  const exportPDF = () => {
    if (!polishedData) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const resumeContent = document.getElementById('resume-preview-container')?.innerHTML;

    printWindow.document.write(`
      <html>
        <head>
          <title>${polishedData.fullName} - Resume</title>
          <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <style>
            body { font-family: 'Inter', sans-serif; color: #0f172a; padding: 0; margin: 0; line-height: 1.6; }
            .resume-wrapper { padding: 40px; max-width: 800px; margin: auto; }
            h1 { font-family: 'Libre Baskerville', serif; color: #0f172a; font-size: 32px; text-align: center; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 2px; }
            .contact-info { text-align: center; font-size: 11px; color: #475569; margin-bottom: 30px; display: flex; justify-content: center; gap: 10px; flex-wrap: wrap; }
            .section { margin-bottom: 25px; }
            .section-title { font-weight: 800; border-bottom: 2px solid #0f172a; text-transform: uppercase; font-size: 12px; letter-spacing: 2px; margin-bottom: 12px; padding-bottom: 4px; color: #0f172a; }
            .summary { font-size: 13px; color: #334155; margin-bottom: 20px; text-align: justify; }
            .entry { margin-bottom: 15px; }
            .entry-header { display: flex; justify-content: space-between; font-weight: 700; font-size: 14px; }
            .entry-sub { display: flex; justify-content: space-between; font-weight: 600; font-size: 12px; color: #475569; margin-bottom: 5px; }
            .points { font-size: 12px; margin: 5px 0 0 18px; padding: 0; color: #334155; }
            .points li { margin-bottom: 4px; }
            .skills-text { font-size: 12px; color: #334155; }
            @media print {
              .no-print { display: none; }
              body { padding: 0; }
              @page { margin: 1.5cm; }
            }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="resume-wrapper">
            ${resumeContent}
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  if (step === 'loading') {
    return (
      <div className="flex flex-col items-center justify-center py-32 animate-in fade-in">
        <div className="relative">
           <Loader2 className="w-16 h-16 text-indigo-600 animate-spin" />
           <Sparkles className="w-6 h-6 text-amber-400 absolute -top-1 -right-1 animate-pulse" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 mt-8 tracking-tight">Polishing Content...</h2>
        <p className="text-slate-500 mt-2 text-center max-w-sm px-6">
          Gemini-3-Flash is optimizing your resume for impact. This will take only a few seconds.
        </p>
      </div>
    );
  }

  if (step === 'preview' && polishedData) {
    return (
      <div className="max-w-4xl mx-auto space-y-6 pb-20 animate-in slide-in-from-bottom-4">
        <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm sticky top-20 z-20">
          <button onClick={() => setStep('form')} className="flex items-center gap-2 text-slate-500 font-bold hover:text-slate-800 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Edit Content
          </button>
          <div className="flex items-center gap-3">
             <button onClick={exportPDF} className="bg-indigo-600 text-white px-6 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-indigo-700 shadow-lg transition-all">
               <FileDown className="w-4 h-4" />
               Download PDF
             </button>
          </div>
        </div>

        <div className="bg-white p-12 md:p-16 rounded-lg shadow-2xl border border-slate-100 font-sans leading-relaxed text-slate-900 mx-auto min-h-[1056px] w-full max-w-[800px]" id="resume-preview-container">
           <style dangerouslySetInnerHTML={{ __html: `
             #resume-preview-container h1 { font-family: 'Libre Baskerville', serif; }
             #resume-preview-container { font-family: 'Inter', sans-serif; }
           ` }} />
           
           <div className="text-center mb-10">
              <h1 className="text-4xl font-black uppercase tracking-[0.1em] text-slate-900 mb-2">{polishedData.fullName}</h1>
              <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-[11px] text-slate-500 font-semibold tracking-wide uppercase">
                <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {polishedData.email}</span>
                <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {polishedData.phone}</span>
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {polishedData.location}</span>
                {polishedData.linkedin && <span className="flex items-center gap-1 font-bold text-indigo-600 tracking-tight"><Linkedin className="w-3 h-3" /> {polishedData.linkedin.replace('https://', '')}</span>}
                {polishedData.portfolio && <span className="flex items-center gap-1 font-bold text-indigo-600 tracking-tight"><Globe className="w-3 h-3" /> {polishedData.portfolio.replace('https://', '')}</span>}
              </div>
           </div>

           <div className="mb-8">
              <h3 className="font-extrabold border-b-2 border-slate-900 uppercase text-[12px] tracking-[0.2em] text-slate-900 mb-3 pb-1">Executive Summary</h3>
              <p className="text-[13px] text-slate-700 leading-relaxed text-justify">{polishedData.summary}</p>
           </div>

           <div className="mb-8">
              <h3 className="font-extrabold border-b-2 border-slate-900 uppercase text-[12px] tracking-[0.2em] text-slate-900 mb-4 pb-1">Professional Experience</h3>
              <div className="space-y-6">
                {(polishedData.experience || []).map((exp, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between items-start font-bold text-[14px] text-slate-900">
                      <span>{exp.title}</span>
                      <span className="text-slate-500 text-[11px] tracking-tight">{exp.date}</span>
                    </div>
                    <div className="font-semibold text-[12px] text-slate-600 mb-2 italic">{exp.company}</div>
                    <ul className="list-disc pl-5 text-[12px] space-y-1.5 text-slate-700">
                      {(exp.points || '').split('\n').map((p, i) => p.trim() ? <li key={i}>{p.replace(/^[-*]\s*/, '')}</li> : null)}
                    </ul>
                  </div>
                ))}
              </div>
           </div>

           <div className="mb-8">
              <h3 className="font-extrabold border-b-2 border-slate-900 uppercase text-[12px] tracking-[0.2em] text-slate-900 mb-4 pb-1">Core Projects</h3>
              <div className="space-y-5">
                {(polishedData.projects || []).map((proj, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between items-start font-bold text-[13px] text-slate-800">
                      <span>{proj.name}</span>
                      <span className="text-indigo-600 text-[10px] font-black uppercase tracking-widest">{proj.tech}</span>
                    </div>
                    <p className="text-[12px] mt-1 text-slate-600 leading-relaxed">{proj.description}</p>
                  </div>
                ))}
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div>
                <h3 className="font-extrabold border-b-2 border-slate-900 uppercase text-[12px] tracking-[0.2em] text-slate-900 mb-3 pb-1">Education</h3>
                <div className="space-y-4">
                  {(polishedData.education || []).map((edu, idx) => (
                    <div key={idx} className="text-[12px]">
                      <div className="font-bold text-slate-800 uppercase text-[13px]">{edu.degree}</div>
                      <div className="font-medium text-slate-500 italic">{edu.school}</div>
                      <div className="flex justify-between mt-0.5 font-bold text-[10px] text-slate-400">
                        <span>{edu.date}</span>
                        {edu.gpa && <span className="text-indigo-600 uppercase">GPA: {edu.gpa}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="font-extrabold border-b-2 border-slate-900 uppercase text-[12px] tracking-[0.2em] text-slate-900 mb-3 pb-1">Technical Skills</h3>
                <div className="text-[12px] text-slate-700 leading-relaxed mb-4">
                  {polishedData.skills}
                </div>
                {polishedData.certifications && (
                  <>
                    <h3 className="font-extrabold border-b border-slate-200 uppercase text-[10px] tracking-[0.2em] text-slate-400 mb-2 pb-1">Certifications</h3>
                    <div className="text-[11px] text-slate-500 font-medium italic">
                      {polishedData.certifications}
                    </div>
                  </>
                )}
              </div>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto pb-20 animate-in fade-in">
      <div className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Executive Resume Builder</h2>
          <p className="text-slate-500 mt-1">High-impact content generation powered by Gemini-3-Flash.</p>
        </div>
        <button 
          onClick={handleGenerate}
          className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all hover:-translate-y-1 active:scale-95"
        >
          <Sparkles className="w-5 h-5" />
          Generate Professional Resume
        </button>
      </div>

      {errorMsg && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-red-700 animate-in shake-in">
          <Trash2 className="w-5 h-5" />
          <p className="text-sm font-medium">{errorMsg}</p>
          <button onClick={() => setErrorMsg(null)} className="ml-auto text-xs font-bold uppercase hover:underline">Dismiss</button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Section icon={<User className="w-5 h-5 text-indigo-600"/>} title="Identity & Profile">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Full Name" name="fullName" value={formData.fullName} onChange={(v) => setFormData(prev => ({ ...prev, fullName: v }))} placeholder="E.g. Alexander Pierce" />
                <Input label="Primary Email" name="email" value={formData.email} onChange={(v) => setFormData(prev => ({ ...prev, email: v }))} placeholder="alex.p@enterprise.com" />
                <Input label="Contact Number" name="phone" value={formData.phone} onChange={(v) => setFormData(prev => ({ ...prev, phone: v }))} placeholder="+1 (555) 012-3456" />
                <Input label="Current Location" name="location" value={formData.location} onChange={(v) => setFormData(prev => ({ ...prev, location: v }))} placeholder="San Francisco, CA" />
                <Input label="LinkedIn URL" name="linkedin" value={formData.linkedin || ''} onChange={(v) => setFormData(prev => ({ ...prev, linkedin: v }))} placeholder="linkedin.com/in/username" />
                <Input label="Portfolio / GitHub" name="portfolio" value={formData.portfolio || ''} onChange={(v) => setFormData(prev => ({ ...prev, portfolio: v }))} placeholder="portfolio.dev" />
             </div>
             <div className="mt-6 p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <p className="text-xs text-amber-700 font-medium leading-relaxed">
                  <strong>AI Engine Active:</strong> Enter your basic details below. Our AI will automatically draft your professional summary and optimize your experience points.
                </p>
             </div>
          </Section>

          <Section icon={<Briefcase className="w-5 h-5 text-indigo-600"/>} title="Work Experience" onAdd={() => addRow('experience')}>
             {formData.experience.map((exp, idx) => (
               <div key={idx} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 mb-4 relative group animate-in slide-in-from-right-2">
                  <button 
                    onClick={() => removeRow(idx, 'experience')}
                    className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <Input label="Role / Title" value={exp.title} onChange={(v) => handleArrayChange(idx, 'title', v, 'experience')} placeholder="Senior Software Engineer" />
                    <Input label="Company Name" value={exp.company} onChange={(v) => handleArrayChange(idx, 'company', v, 'experience')} placeholder="Global Tech Corp" />
                    <Input label="Tenure Period" value={exp.date} onChange={(v) => handleArrayChange(idx, 'date', v, 'experience')} placeholder="Jan 2020 - Present" />
                  </div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Key Achievements (Draft)</label>
                  <textarea 
                    value={exp.points} 
                    onChange={(e) => handleArrayChange(idx, 'points', e.target.value, 'experience')}
                    placeholder="List what you did. AI will transform these into achievement-based bullets."
                    className="w-full bg-white border border-slate-200 rounded-xl p-4 text-sm h-32 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
               </div>
             ))}
          </Section>

          <Section icon={<Code className="w-5 h-5 text-indigo-600"/>} title="Key Projects" onAdd={() => addRow('projects')}>
             {formData.projects.map((proj, idx) => (
               <div key={idx} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 mb-4 relative animate-in slide-in-from-right-2">
                  <button 
                    onClick={() => removeRow(idx, 'projects')}
                    className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <Input label="Project Name" value={proj.name} onChange={(v) => handleArrayChange(idx, 'name', v, 'projects')} />
                    <Input label="Tech Stack" value={proj.tech} onChange={(v) => handleArrayChange(idx, 'tech', v, 'projects')} placeholder="React, Node.js, AWS..." />
                  </div>
                  <textarea 
                    value={proj.description} 
                    onChange={(e) => handleArrayChange(idx, 'description', e.target.value, 'projects')}
                    placeholder="Project scope and outcome..."
                    className="w-full bg-white border border-slate-200 rounded-xl p-4 text-sm h-24 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
               </div>
             ))}
          </Section>
        </div>

        <div className="space-y-8">
           <Section icon={<Award className="w-5 h-5 text-indigo-600"/>} title="Expertise Area">
              <div className="space-y-6">
                 <div>
                   <label className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1 block">Skills (Comma Separated)</label>
                   <textarea 
                      name="skills" 
                      value={formData.skills} 
                      onChange={handleChange}
                      placeholder="E.g. Python, SQL, Project Management..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm h-32 focus:ring-2 focus:ring-indigo-500 transition-all"
                   />
                 </div>
                 <div>
                   <label className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1 block">Notable Certifications</label>
                   <textarea 
                      name="certifications" 
                      value={formData.certifications} 
                      onChange={handleChange}
                      placeholder="E.g. AWS Solutions Architect, PMP..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm h-24 focus:ring-2 focus:ring-indigo-500 transition-all"
                   />
                 </div>
              </div>
           </Section>

           <Section icon={<GraduationCap className="w-5 h-5 text-indigo-600"/>} title="Education" onAdd={() => addRow('education')}>
             {formData.education.map((edu, idx) => (
               <div key={idx} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-4 relative">
                  <button 
                    onClick={() => removeRow(idx, 'education')}
                    className="absolute top-2 right-2 text-slate-300 hover:text-red-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <div className="space-y-3">
                    <Input label="Degree / Diploma" value={edu.degree} onChange={(v) => handleArrayChange(idx, 'degree', v, 'education')} />
                    <Input label="Institution" value={edu.school} onChange={(v) => handleArrayChange(idx, 'school', v, 'education')} />
                    <div className="grid grid-cols-2 gap-2">
                       <Input label="Year" value={edu.date} onChange={(v) => handleArrayChange(idx, 'date', v, 'education')} />
                       <Input label="GPA" value={edu.gpa || ''} onChange={(v) => handleArrayChange(idx, 'gpa', v, 'education')} />
                    </div>
                  </div>
               </div>
             ))}
          </Section>

           <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-700"></div>
              <Sparkles className="w-8 h-8 text-amber-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Ready to Shine?</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                Generate a text-based, ATS-optimized executive resume in seconds.
              </p>
              <button 
                onClick={handleGenerate}
                className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-500 transition-all shadow-lg active:scale-95"
              >
                PRODUCE RESUME
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;
