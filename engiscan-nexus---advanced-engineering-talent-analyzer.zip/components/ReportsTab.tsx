
import React, { useState } from 'react';
import { Search, Download, Trash2, FileText, Filter, Calendar, ExternalLink, ShieldCheck } from 'lucide-react';
import { SavedReport } from '../types';
import { storageService } from '../services/storageService';

interface ReportsTabProps { reports: SavedReport[]; onDelete: () => void; }

const ReportsTab: React.FC<ReportsTabProps> = ({ reports, onDelete }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'ALL' | 'SINGLE' | 'CONSOLIDATED' | 'ATS' | 'GENERATED_RESUME'>('ALL');

  const filteredReports = reports.filter(r => {
    const matchesSearch = r.name.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'ALL' || r.type === filter;
    return matchesSearch && matchesFilter;
  });

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to permanently delete this analysis report? This action cannot be undone.')) {
      storageService.deleteReport(id);
      onDelete();
    }
  };

  const generateReportHTML = (report: SavedReport) => {
    const isATS = report.type === 'ATS';
    const isComparison = report.type === 'CONSOLIDATED';
    const isGeneratedResume = report.type === 'GENERATED_RESUME';
    
    let contentHTML = '';

    if (isATS) {
      const data = report.data || {};
      contentHTML = `
        <div class="score-circle">
          <h2>${data.score || 0}</h2>
          <p>ATS SCORE</p>
        </div>
        <div class="section">
          <h3>Overall Feedback</h3>
          <p>${data.overallFeedback || 'No feedback available.'}</p>
        </div>
        <div class="section">
          <h3>Missing Keywords</h3>
          <div class="tags">
            ${(data.missingKeywords || []).map((k: string) => `<span class="tag">${k}</span>`).join('')}
          </div>
        </div>
        <div class="section">
          <h3>Detailed Breakdown</h3>
          ${(data.sections || []).map((s: any) => `
            <div class="card">
              <div style="display:flex; justify-content:space-between; align-items:center">
                <strong>${s.category || 'Section'}</strong>
                <span class="score-badge">${s.score || 0}%</span>
              </div>
              <p>${s.feedback || ''}</p>
              <ul>
                ${(s.suggestions || []).map((sug: string) => `<li>${sug}</li>`).join('')}
              </ul>
            </div>
          `).join('')}
        </div>
      `;
    } else if (isComparison) {
      const { comparison, candidates } = report.data || {};
      const actualComparison = comparison || {};
      contentHTML = `
        <div class="section">
          <h3>Best Fit Identified</h3>
          <h2 style="color: #4f46e5; margin: 10px 0;">${(candidates || []).find((c: any) => c.id === actualComparison.bestFitId)?.fullName || 'Top Candidate'}</h2>
          <div class="card" style="background: #f5f3ff; border-left: 4px solid #4f46e5;">
            <p><strong>Reasoning:</strong> ${actualComparison.consolidatedReasoning || 'N/A'}</p>
          </div>
        </div>
        <div class="section">
          <h3>Full Rankings</h3>
          ${(actualComparison.ranking || []).map((r: any, i: number) => `
            <div class="card">
              <strong>${i + 1}. ${(candidates || []).find((c: any) => c.id === r.candidateId)?.fullName || 'Candidate'}</strong>
              <span class="score-badge">${r.score || 0}%</span>
              <p>${r.reason || ''}</p>
            </div>
          `).join('')}
        </div>
      `;
    } else if (isGeneratedResume) {
      const data = report.data || {};
      contentHTML = `
        <div style="text-align:center; border-bottom: 2px solid #333; padding-bottom:10px; margin-bottom:20px;">
          <h1 style="margin:0; text-transform:uppercase;">${data.fullName || 'RESUME'}</h1>
          <p style="font-size:12px; margin:5px 0;">${data.email || ''} | ${data.phone || ''} | ${data.location || ''}</p>
          <p style="font-size:12px; margin:0;">${data.linkedin ? `LinkedIn: ${data.linkedin}` : ''} ${data.portfolio ? `| Portfolio: ${data.portfolio}` : ''}</p>
        </div>
        <div style="margin-bottom:20px; font-size:13px; font-style:italic;">${data.summary || ''}</div>
        <div class="section">
          <h3>Professional Experience</h3>
          ${(data.experience || []).map((exp: any) => `
            <div class="card">
              <div style="display:flex; justify-content:space-between; font-weight:bold;">
                <span>${exp.title || ''}</span>
                <span>${exp.date || ''}</span>
              </div>
              <div style="font-style:italic; font-size:12px;">${exp.company || ''}</div>
              <ul style="font-size:12px; margin-top:5px;">
                ${(exp.points || '').split('\n').map((p: string) => p.trim() ? `<li>${p.replace(/^[-*]\s*/, '')}</li>` : '').join('')}
              </ul>
            </div>
          `).join('')}
        </div>
        <div class="section">
          <h3>Technical Projects</h3>
          ${(data.projects || []).map((proj: any) => `
            <div class="card">
              <div style="display:flex; justify-content:space-between; font-weight:bold;">
                <span>${proj.name || ''}</span>
                <span style="color:#4f46e5;">${proj.tech || ''}</span>
              </div>
              <p style="font-size:12px;">${proj.description || ''}</p>
            </div>
          `).join('')}
        </div>
        <div class="section">
          <h3>Education</h3>
          ${(data.education || []).map((edu: any) => `
            <div class="card">
              <div style="display:flex; justify-content:space-between; font-weight:bold;">
                <span>${edu.degree || ''}</span>
                <span>${edu.date || ''}</span>
              </div>
              <div style="font-size:12px;">${edu.school || ''} ${edu.gpa ? `| GPA: ${edu.gpa}` : ''}</div>
            </div>
          `).join('')}
        </div>
      `;
    } else {
      const data = report.data || {};
      contentHTML = `
        <div class="section">
          <h3>Candidate Profile Evaluation</h3>
          <h2>${data.candidateName || 'Candidate Profile'}</h2>
          <div class="score-badge" style="font-size: 1.5rem; padding: 10px 20px;">Match Score: ${data.score || 0}%</div>
          <p><strong>Role Fit:</strong> ${data.roleFitRating || 'N/A'}</p>
        </div>
        <div class="section">
          <h3>SWOT Analysis</h3>
          <div class="grid">
            <div class="card">
              <h4>Strengths</h4>
              <ul>${(data.strengths || []).map((s: string) => `<li>${s}</li>`).join('')}</ul>
            </div>
            <div class="card">
              <h4>Weaknesses</h4>
              <ul>${(data.weaknesses || []).map((w: string) => `<li>${w}</li>`).join('')}</ul>
            </div>
          </div>
        </div>
        <div class="section">
          <h3>Detailed Analysis</h3>
          <p>${data.detailedAnalysis || 'No analysis available.'}</p>
        </div>
      `;
    }

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${report.name}</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; line-height: 1.6; padding: 40px; max-width: 900px; margin: auto; background: #f8fafc; }
          .header { text-align: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 40px; }
          .header h1 { color: #4f46e5; margin-bottom: 5px; }
          .header p { color: #64748b; font-size: 0.9rem; }
          .section { margin-bottom: 40px; }
          h3 { border-left: 4px solid #4f46e5; padding-left: 15px; color: #334155; }
          .card { background: white; border: 1px solid #e2e8f0; padding: 20px; border-radius: 12px; margin-bottom: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
          .score-circle { width: 120px; height: 120px; border-radius: 50%; background: #4f46e5; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; margin: 20px auto; box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.4); }
          .score-circle h2 { margin: 0; font-size: 2.5rem; }
          .score-circle p { margin: 0; font-size: 0.7rem; font-weight: bold; }
          .score-badge { display: inline-block; background: #e0e7ff; color: #4338ca; font-weight: bold; padding: 5px 12px; border-radius: 999px; font-size: 0.8rem; }
          .tag { display: inline-block; background: #f1f5f9; padding: 4px 10px; border-radius: 6px; margin: 2px; font-size: 0.75rem; color: #475569; border: 1px solid #e2e8f0; }
          .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
          ul { padding-left: 20px; }
          li { margin-bottom: 5px; font-size: 0.9rem; }
          @media print { body { background: white; padding: 0; } .card { box-shadow: none; border: 1px solid #eee; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>EngiScan Nexus AI Report</h1>
          <p>Generated on ${new Date(report.createdAt).toLocaleString()} * Report ID: ${report.id}</p>
        </div>
        ${contentHTML}
        <div style="margin-top: 100px; text-align: center; color: #94a3b8; font-size: 0.8rem; border-top: 1px solid #eee; padding-top: 20px;">
          (c) 2025 EngiScan Nexus Intelligence Systems. This report was generated using Gemini 3.0 Pro.
        </div>
      </body>
      </html>
    `;
  };

  const handleDownload = (report: SavedReport) => {
    const htmlContent = generateReportHTML(report);
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.name.replace(/\s+/g, '_')}_Report.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search reports by candidate or file name..."
            className="w-full pl-11 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select 
            className="flex-1 md:w-48 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={filter}
            onChange={(e) => setFilter(e.target.value as any)}
          >
            <option value="ALL">All Analysis</option>
            <option value="SINGLE">Profiles</option>
            <option value="CONSOLIDATED">Comparisons</option>
            <option value="ATS">ATS Scores</option>
            <option value="GENERATED_RESUME">AI Resumes</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredReports.length > 0 ? filteredReports.reverse().map((report) => (
          <div key={report.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-indigo-300 hover:shadow-xl transition-all flex flex-col group">
            <div className="p-5 flex-1">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg ${
                  report.type === 'CONSOLIDATED' ? 'bg-indigo-50 text-indigo-600' : 
                  report.type === 'ATS' ? 'bg-amber-50 text-amber-600' : 
                  report.type === 'GENERATED_RESUME' ? 'bg-violet-50 text-violet-600' : 'bg-emerald-50 text-emerald-600'
                }`}>
                  <FileText className="w-6 h-6" />
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleDownload(report)}
                    className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                    title="Download Formatted Report"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => handleDelete(report.id)}
                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                    title="Delete Analysis"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
              
              <h4 className="font-bold text-slate-800 text-lg group-hover:text-indigo-600 transition-colors mb-2 line-clamp-1">{report.name}</h4>
              <div className="flex flex-wrap gap-2 mb-4">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  report.type === 'CONSOLIDATED' ? 'bg-indigo-100 text-indigo-700' : 
                  report.type === 'ATS' ? 'bg-amber-100 text-amber-700' : 
                  report.type === 'GENERATED_RESUME' ? 'bg-violet-100 text-violet-700' : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {report.type === 'ATS' ? 'ATS Optimizer' : report.type === 'CONSOLIDATED' ? 'Multi-Comparison' : report.type === 'GENERATED_RESUME' ? 'AI Generated Resume' : 'Single Profile'}
                </span>
              </div>

              <div className="space-y-3 mt-4">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Calendar className="w-4 h-4" />
                  Analyzed on {new Date(report.createdAt).toLocaleDateString()}
                </div>
              </div>
            </div>

            <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase">
                <ShieldCheck className="w-3.5 h-3.5" />
                Validated by AI
              </div>
              <button 
                className="text-xs font-bold text-indigo-600 flex items-center gap-1 hover:gap-2 transition-all"
                onClick={() => handleDownload(report)}
              >
                Download HTML
                <Download className="w-3 h-3" />
              </button>
            </div>
          </div>
        )) : (
          <div className="col-span-full py-20 text-center bg-white rounded-2xl border-2 border-dashed border-slate-200">
            <div className="mx-auto w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-slate-200" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">No reports matched your criteria</h3>
            <p className="text-sm text-slate-500 mt-1 max-w-xs mx-auto">Try changing your filters or upload new resumes to generate analytical data.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportsTab;
