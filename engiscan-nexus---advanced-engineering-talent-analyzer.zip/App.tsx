
import React, { useState, useEffect } from 'react';
import { Layout, Upload, FileText, Users, PieChart, Shield, User as UserIcon, Trash2, LogOut, FilePlus } from 'lucide-react';
import { UserRole, ResumeData, SavedReport } from './types';
import { storageService } from './services/storageService';
import Dashboard from './components/Dashboard';
import UploadSection from './components/UploadSection';
import ReportsTab from './components/ReportsTab';
import LoginPage from './components/LoginPage';
import ResumeBuilder from './components/ResumeBuilder';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'upload' | 'builder' | 'reports'>('dashboard');
  const [role, setRole] = useState<UserRole>(UserRole.ADMIN);
  const [candidates, setCandidates] = useState<ResumeData[]>([]);
  const [reports, setReports] = useState<SavedReport[]>([]);

  useEffect(() => {
    const auth = localStorage.getItem('engiscan_auth');
    if (auth === 'true') {
      setIsAuthenticated(true);
    }
    setCandidates(storageService.getCandidates());
    setReports(storageService.getReports());
  }, []);

  const handleLogin = () => {
    localStorage.setItem('engiscan_auth', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('engiscan_auth');
    setIsAuthenticated(false);
  };

  const handleDataUpdate = () => {
    setCandidates(storageService.getCandidates());
    setReports(storageService.getReports());
  };

  const clearData = () => {
    if (confirm('Are you sure you want to clear all data?')) {
      storageService.clearCandidates();
      setCandidates([]);
    }
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex-shrink-0">
        <div className="p-6">
          <h1 className="text-2xl font-bold flex items-center gap-2 text-indigo-400">
            <Layout className="w-8 h-8" />
            EngiScan <span className="text-white">Nexus</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Advanced Talent Analytics</p>
        </div>

        <nav className="mt-6 px-4 space-y-2">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <PieChart className="w-5 h-5" />
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'upload' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <Upload className="w-5 h-5" />
            Analyze Resumes
          </button>
          <button
            onClick={() => setActiveTab('builder')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'builder' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <FilePlus className="w-5 h-5" />
            Resume Builder
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'reports' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <FileText className="w-5 h-5" />
            Reports
          </button>
        </nav>

        <div className="mt-auto p-6 border-t border-slate-800 space-y-4">
          <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-lg">
            <div className={`p-2 rounded-full ${role === UserRole.ADMIN ? 'bg-indigo-500' : 'bg-emerald-500'}`}>
              {role === UserRole.ADMIN ? <Shield className="w-4 h-4" /> : <UserIcon className="w-4 h-4" />}
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-sm font-medium truncate">{role === UserRole.ADMIN ? 'Administrator' : 'HR Specialist'}</p>
              <button 
                onClick={() => setRole(role === UserRole.ADMIN ? UserRole.USER : UserRole.ADMIN)}
                className="text-xs text-indigo-400 hover:underline"
              >
                Switch to {role === UserRole.ADMIN ? 'User' : 'Admin'}
              </button>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            {role === UserRole.ADMIN && (
              <button 
                onClick={clearData}
                className="w-full flex items-center gap-2 text-xs text-red-400 hover:text-red-300 transition-colors p-2 rounded hover:bg-slate-800"
              >
                <Trash2 className="w-4 h-4" />
                Reset Database
              </button>
            )}
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors p-2 rounded hover:bg-slate-800"
            >
              <LogOut className="w-4 h-4" />
              Logout Session
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-slate-50">
        <header className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between sticky top-0 z-10">
          <h2 className="text-xl font-semibold text-slate-800 capitalize">{activeTab}</h2>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-xs text-slate-500">Processing Node</p>
              <p className="text-sm font-medium text-emerald-600 flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                Gemini-3-Pro Online
              </p>
            </div>
          </div>
        </header>

        <div className="p-8">
          {activeTab === 'dashboard' && (
            <Dashboard candidates={candidates} reports={reports} />
          )}
          {activeTab === 'upload' && (
            <UploadSection 
              candidates={candidates} 
              onComplete={handleDataUpdate}
              role={role}
            />
          )}
          {activeTab === 'builder' && (
            <ResumeBuilder />
          )}
          {activeTab === 'reports' && (
            <ReportsTab reports={reports} onDelete={handleDataUpdate} />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
